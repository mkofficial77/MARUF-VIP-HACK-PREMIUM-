# OWNER MARUF APK BUILDER PRO

A starter PWA + cloud Android build service for packaging web projects as Android APKs.

## What is included
- Mobile-first PWA dashboard (URL / paste HTML / ZIP upload)
- App name, package ID, version, icon upload
- Build history in browser local storage
- Node.js API with build queue, validation, and status/download endpoints
- Dockerfile with Android SDK + Gradle build environment
- Android WebView wrapper template
- APK output download endpoint

## Important
This is a deployable starter, not a hosted service. You must deploy the API/container to a server that can run Docker and Android SDK builds, then set `API_BASE` in `public/app.js`.
A static GitHub Pages site alone cannot compile APKs. Do not put admin secrets or signing keys in the PWA frontend.

The wrapper loads the selected start URL inside Android WebView. It does not force arbitrary third-party pages to run invisibly in the background. Android may pause WebView/network work when the app is backgrounded; persistent background work requires a separately designed, user-visible Android foreground service and must comply with Android policies.

## Run locally (API)
1. Install Docker and Docker Compose.
2. Copy `.env.example` to `.env` and set a long `ADMIN_TOKEN`.
3. `docker compose up --build`
4. Open `http://localhost:8080`.
5. For production, use HTTPS and a persistent volume. Configure `API_BASE` in `public/app.js` to your deployed API URL.

## Build flow
The API creates a temporary Android project per request, copies either a validated URL wrapper or uploaded web files into the app assets, runs Gradle, and stores the resulting APK under `data/builds`.
Only ZIP files containing ordinary web assets are accepted. ZIP path traversal is rejected. Builds are size-limited and concurrent builds are capped.

## Admin
The starter admin page uses a bearer token. Set `ADMIN_TOKEN` on the server. In production, replace this simple gate with proper user accounts, rate limits, audit logging, and secure secret management.

## Signing
Debug APKs are produced by default for testing. A supplied PNG/JPEG/WebP icon is copied as the launcher drawable (Android accepts raster drawable resources; square PNG is recommended). A Play-distributable release requires a properly protected signing key and a release signing configuration. Never upload keystores or passwords to a public repository.

## PWA hosting
You can host `public/` on HTTPS static hosting. The API must be separately deployed. Set:
`window.API_BASE = "https://YOUR-API-HOST";`
near the top of `public/app.js`.
