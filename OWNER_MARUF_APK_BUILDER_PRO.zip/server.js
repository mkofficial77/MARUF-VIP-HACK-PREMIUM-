const express = require("express");
const multer = require("multer");
const AdmZip = require("adm-zip");
const { v4: uuid } = require("uuid");
const fs = require("fs");
const path = require("path");
const os = require("os");
const { spawn } = require("child_process");

const app = express();
const PORT = process.env.PORT || 8080;
const ROOT = __dirname;
const DATA = path.join(ROOT, "data");
const BUILDS = path.join(DATA, "builds");
const TMP = path.join(DATA, "tmp");
const PUBLIC = path.join(ROOT, "public");
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || "";
const MAX_MB = Number(process.env.MAX_UPLOAD_MB || 25);
const MAX_ACTIVE = Number(process.env.MAX_CONCURRENT_BUILDS || 1);
[DATA, BUILDS, TMP].forEach(p => fs.mkdirSync(p, {recursive:true}));
app.use(express.json({limit:"1mb"}));
app.use(express.static(PUBLIC));
const upload = multer({dest:TMP, limits:{fileSize:MAX_MB*1024*1024, files:2}});

const jobs = new Map();
let active = 0;
const adminOnly = (req,res,next) => {
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i,"");
  if (!ADMIN_TOKEN || token !== ADMIN_TOKEN) return res.status(401).json({error:"Admin authentication required"});
  next();
};
const safeText = (v,max=120) => String(v || "").trim().slice(0,max);
const validPackage = v => /^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*){1,5}$/.test(v);
const validUrl = v => {
  try { const u = new URL(v); return u.protocol === "https:" && !["localhost","127.0.0.1","0.0.0.0"].includes(u.hostname); }
  catch { return false; }
};
function run(cmd,args,cwd) {
  return new Promise((resolve,reject)=>{
    const p=spawn(cmd,args,{cwd,stdio:["ignore","pipe","pipe"]});
    let out="",err="";
    p.stdout.on("data",d=>out+=d.toString());
    p.stderr.on("data",d=>err+=d.toString());
    p.on("close",code=>code===0?resolve(out+"\n"+err):reject(new Error((err||out).slice(-5000)||`Command failed: ${code}`)));
  });
}
function write(p,s){fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,s);}
function xmlEscape(s){return String(s).replace(/[<>&'"]/g,c=>({"<":"&lt;",">":"&gt;","&":"&amp;","'":"&apos;",'"':"&quot;"}[c]));}
function projectFiles(job,dir,webDir){
  const appDir=path.join(dir,"app/src/main");
  const pkgPath=job.packageName.replace(/\./g,"/");
  const activity=`package ${job.packageName};
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.net.Uri;
import android.content.Intent;
import android.graphics.Bitmap;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
  private WebView web;
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    web = new WebView(this);
    WebSettings s=web.getSettings();
    s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    s.setLoadsImagesAutomatically(true); s.setMediaPlaybackRequiresUserGesture(true);
    s.setAllowFileAccess(false); s.setAllowContentAccess(false);
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){
        Uri u=r.getUrl(); String scheme=u.getScheme();
        if ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)) return false;
        try { startActivity(new Intent(Intent.ACTION_VIEW,u)); } catch(Exception ignored) {}
        return true;
      }
    });
    web.setWebChromeClient(new WebChromeClient());
    setContentView(web);
    web.loadUrl("${job.startUrl.replace(/\\/g,"\\\\").replace(/"/g,'\\"')}");
  }
  @Override public void onBackPressed(){ if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}`;
  write(path.join(appDir,"java",pkgPath,"MainActivity.java"),activity);
  const iconAttr=job.iconPath ? ' android:icon="@drawable/app_icon"' : '';
  const manifest=`<manifest xmlns:android="http://schemas.android.com/apk/res/android"><uses-permission android:name="android.permission.INTERNET"/><application${iconAttr} android:label="${xmlEscape(job.appName)}" android:usesCleartextTraffic="false" android:theme="@android:style/Theme.Material.Light.NoActionBar"><activity android:name=".MainActivity" android:exported="true" android:configChanges="keyboardHidden|orientation|screenSize"><intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter></activity></application></manifest>`;
  write(path.join(appDir,"AndroidManifest.xml"),manifest);
  write(path.join(dir,"settings.gradle"),"pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }\ndependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral() } }\nrootProject.name = 'WebWrapper'\ninclude ':app'\n");
  write(path.join(dir,"build.gradle"),"plugins { id 'com.android.application' version '8.7.3' apply false }\n");
  write(path.join(dir,"gradle.properties"),"org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8\nandroid.useAndroidX=true\n");
  write(path.join(dir,"app/build.gradle"),`plugins { id 'com.android.application' }\n\nandroid { namespace '${job.packageName}'; compileSdk 35\n defaultConfig { applicationId '${job.packageName}'; minSdk 23; targetSdk 35; versionCode ${job.versionCode}; versionName '${job.versionName}' }\n}\n`);
  if (job.mode === "files" && webDir) {
    const assets=path.join(appDir,"assets","site"); fs.mkdirSync(assets,{recursive:true});
    fs.cpSync(webDir,assets,{recursive:true});
    const index=path.join(assets,"index.html");
    if(fs.existsSync(index)) {
      const src=fs.readFileSync(index,"utf8");
      // The user-provided site runs as a local asset; remote links still follow WebView navigation policy.
      write(path.join(appDir,"java",pkgPath,"MainActivity.java"),activity.replace(job.startUrl,"file:///android_asset/site/index.html"));
    }
  }
  if(job.iconPath && fs.existsSync(job.iconPath)) {
    // Android adaptive icon generation is intentionally left to a production icon pipeline.
    const res=path.join(appDir,"res/drawable"); fs.mkdirSync(res,{recursive:true});
    fs.copyFileSync(job.iconPath,path.join(res,"app_icon.png"));
  }
}
async function buildJob(job){
  const dir=path.join(TMP,job.id); fs.mkdirSync(dir,{recursive:true});
  let webDir=null;
  try{
    if(job.mode==="code"){
      webDir=path.join(dir,"web"); fs.mkdirSync(webDir,{recursive:true});
      write(path.join(webDir,"index.html"),job.htmlCode);
      job.startUrl="file:///android_asset/site/index.html";
    }
    if(job.mode==="files"){
      webDir=path.join(dir,"web"); fs.mkdirSync(webDir,{recursive:true});
      const zip=new AdmZip(job.zipPath);
      for(const entry of zip.getEntries()){
        const name=entry.entryName.replace(/\\/g,"/");
        if(name.startsWith("/") || name.split("/").includes("..")) throw new Error("Unsafe ZIP path rejected");
        if(!entry.isDirectory) {
          const dest=path.join(webDir,name);
          if(!dest.startsWith(webDir+path.sep)) throw new Error("Unsafe archive entry");
          fs.mkdirSync(path.dirname(dest),{recursive:true}); fs.writeFileSync(dest,entry.getData());
        }
      }
      if(!fs.existsSync(path.join(webDir,"index.html"))) throw new Error("ZIP must contain index.html at its root");
      job.startUrl="file:///android_asset/site/index.html";
    }
    projectFiles(job,dir,webDir);
    job.log="Gradle build started";
    await run("gradle",["--no-daemon","assembleDebug"],dir);
    const apk=path.join(dir,"app/build/outputs/apk/debug/app-debug.apk");
    if(!fs.existsSync(apk)) throw new Error("Gradle completed but APK output was not found");
    const out=path.join(BUILDS,job.id+".apk"); fs.copyFileSync(apk,out);
    job.status="complete"; job.apkPath=out; job.finishedAt=new Date().toISOString();
  }catch(e){job.status="failed";job.error=String(e.message||e).slice(0,5000);job.finishedAt=new Date().toISOString();}
  finally{
    if(job.zipPath) try{fs.unlinkSync(job.zipPath)}catch{}
    try{fs.rmSync(dir,{recursive:true,force:true})}catch{}
    active--; pump();
  }
}
const queue=[];
function pump(){while(active<MAX_ACTIVE && queue.length){const j=queue.shift();active++;j.status="building";buildJob(j);}}
app.post("/api/build",upload.fields([{name:"projectZip",maxCount:1},{name:"icon",maxCount:1}]),(req,res)=>{
  const b=req.body||{};
  const mode=safeText(b.mode,20);
  const appName=safeText(b.appName,50);
  const packageName=safeText(b.packageName,120);
  const versionName=safeText(b.versionName||"1.0.0",20);
  const versionCode=Math.max(1,Math.min(999999,parseInt(b.versionCode||"1",10)||1));
  const startUrl=safeText(b.url,2048);
  if(!appName || !validPackage(packageName)) return res.status(400).json({error:"App name and valid package ID (example: com.example.app) are required"});
  if(!["url","code","files"].includes(mode)) return res.status(400).json({error:"Unsupported build mode"});
  if(mode==="url" && !validUrl(startUrl)) return res.status(400).json({error:"Use a valid public HTTP(S) URL"});
  if(mode==="code" && !safeText(b.htmlCode, 500000).trim()) return res.status(400).json({error:"Paste your HTML source"});
  if(mode==="files" && !(req.files?.projectZip?.[0])) return res.status(400).json({error:"Upload a ZIP containing index.html"});
  const id=uuid();
  const iconPath=req.files?.icon?.[0]?.path||null;
  const job={id,appName,packageName,versionName,versionCode,mode,startUrl,htmlCode:safeText(b.htmlCode,500000),status:"queued",createdAt:new Date().toISOString(),zipPath:req.files?.projectZip?.[0]?.path||null,iconPath};
  jobs.set(id,job); queue.push(job); pump();
  res.json({id,status:job.status});
});
app.get("/api/build/:id",(req,res)=>{
  const j=jobs.get(req.params.id); if(!j) return res.status(404).json({error:"Build not found"});
  res.json({id:j.id,status:j.status,error:j.error||null,createdAt:j.createdAt,finishedAt:j.finishedAt||null,downloadUrl:j.status==="complete"?`/api/build/${j.id}/download`:null});
});
app.get("/api/build/:id/download",(req,res)=>{
  const j=jobs.get(req.params.id); if(!j||j.status!=="complete"||!j.apkPath||!fs.existsSync(j.apkPath)) return res.status(404).json({error:"APK not available"});
  res.download(j.apkPath,`${j.appName.replace(/[^a-z0-9_-]/gi,"_")}.apk`);
});
app.get("/api/admin/builds",adminOnly,(req,res)=>res.json([...jobs.values()].map(j=>({id:j.id,appName:j.appName,packageName:j.packageName,status:j.status,createdAt:j.createdAt,finishedAt:j.finishedAt||null,error:j.error||null})).reverse()));
app.get("/api/health",(req,res)=>res.json({ok:true,active,queued:queue.length}));
app.listen(PORT,()=>console.log(`APK Builder API listening on ${PORT}`));
