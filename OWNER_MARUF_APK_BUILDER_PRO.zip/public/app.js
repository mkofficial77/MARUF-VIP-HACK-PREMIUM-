// Set this to your deployed HTTPS API origin when PWA and API are hosted separately.
window.API_BASE = window.API_BASE || "";
const $=s=>document.querySelector(s);
let mode="url", activeJob=null, pollHandle=null;
const form=$("#buildForm"), result=$("#result");
document.querySelectorAll(".tab").forEach(btn=>btn.addEventListener("click",()=>{
  document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===btn));
  mode=btn.dataset.tab; $("#urlFields").hidden=mode!=="url"; $("#fileFields").hidden=mode!=="files";
  form.elements.url.required=mode==="url"; form.elements.projectZip.required=mode==="files";
}));
function getHistory(){try{return JSON.parse(localStorage.getItem("om_apk_history")||"[]")}catch{return[]}}
function saveHistory(h){localStorage.setItem("om_apk_history",JSON.stringify(h.slice(0,30)));renderHistory()}
function renderHistory(){const h=getHistory();$("#history").innerHTML=h.length?h.map(x=>`<div class="historyItem"><div><b>${esc(x.name)}</b><small>${esc(x.packageName)} · ${new Date(x.createdAt).toLocaleString()}</small></div><span>${esc(x.status.toUpperCase())}</span></div>`).join(""):'<p class="muted">No builds yet.</p>'}
function esc(s){return String(s||"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function showStatus(status,msg){result.hidden=false;$("#status").textContent=status.toUpperCase();$("#message").textContent=msg;$("#progress").style.width=status==="complete"?"100%":status==="failed"?"100%":status==="building"?"65%":"20%"}
async function poll(id){
  try{
    const r=await fetch(`${API_BASE}/api/build/${id}`),j=await r.json(); if(!r.ok)throw Error(j.error||"Status unavailable");
    showStatus(j.status,j.error||`Build ${j.status}.`);
    const h=getHistory(),i=h.findIndex(x=>x.id===id);if(i>=0){h[i].status=j.status;saveHistory(h)}
    if(j.status==="complete"){const a=$("#download");a.hidden=false;a.href=API_BASE+j.downloadUrl;a.download="app.apk";clearInterval(pollHandle)}
    if(j.status==="failed")clearInterval(pollHandle);
  }catch(e){showStatus("error",e.message);clearInterval(pollHandle)}
}
form.addEventListener("submit",async e=>{
  e.preventDefault();const btn=$("#buildBtn");btn.disabled=true;btn.textContent="SUBMITTING BUILD…";$("#download").hidden=true;
  const fd=new FormData(form);fd.set("mode",mode);
  try{
    const r=await fetch(`${API_BASE}/api/build`,{method:"POST",body:fd});const j=await r.json();if(!r.ok)throw Error(j.error||"Build request failed");
    activeJob=j.id;saveHistory([{id:j.id,name:fd.get("appName"),packageName:fd.get("packageName"),status:j.status,createdAt:new Date().toISOString()},...getHistory()]);
    showStatus(j.status,"Build submitted. Keep this page open to follow progress.");if(pollHandle)clearInterval(pollHandle);await poll(j.id);pollHandle=setInterval(()=>poll(j.id),3000);
  }catch(err){showStatus("failed",err.message)}finally{btn.disabled=false;btn.innerHTML='BUILD APK <span>↗</span>'}
});
$("#clearHistory").onclick=()=>{localStorage.removeItem("om_apk_history");renderHistory()};
$("#loadAdmin").onclick=async()=>{
  const token=$("#adminToken").value.trim();if(!token){$("#adminList").textContent="Enter the server admin token.";return}
  try{const r=await fetch(`${API_BASE}/api/admin/builds`,{headers:{Authorization:`Bearer ${token}`}});const data=await r.json();if(!r.ok)throw Error(data.error||"Admin request failed");
  $("#adminList").innerHTML=data.map(x=>`<div class="historyItem"><div><b>${esc(x.appName)}</b><small>${esc(x.packageName)} · ${esc(x.id)}</small></div><span>${esc(x.status)}</span></div>`).join("")||"No server builds.";
  }catch(e){$("#adminList").textContent=e.message}
};
renderHistory();
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("/sw.js").catch(()=>{}));
